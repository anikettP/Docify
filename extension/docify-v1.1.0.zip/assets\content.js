function e(){let e=``,t=``,n=``,r=document.querySelector(`meta[name="description"], meta[property="og:description"]`);r&&(e=r.getAttribute(`content`)||``);let i=document.querySelector(`meta[name="author"], meta[property="article:author"], [rel="author"]`);i&&(t=i.getAttribute(`content`)||i.textContent?.trim()||``);let a=document.querySelector(`meta[property="article:published_time"], time[datetime]`);return a&&(n=a.getAttribute(`content`)||a.getAttribute(`datetime`)||``),{description:e,author:t,publishedDate:n}}function t(){let e=[],t=(document.querySelector(`article, [role="main"], main, .article-content, .post-content, #content, .entry-content`)||document.body).cloneNode(!0);[`script`,`style`,`noscript`,`iframe`,`nav`,`header`,`footer`,`aside`,`.advertisement`,`.ad`,`.ads`,`.sponsor`,`.social-share`,`.share-buttons`,`.share-bar`,`.cookie-banner`,`.gdpr-banner`,`#consent-banner`,`.comments`,`#comments`,`.disqus`,`[aria-hidden="true"]`,`.hidden`].forEach(e=>{t.querySelectorAll(e).forEach(e=>e.remove())});let n=Array.from(t.querySelectorAll(`h1, h2, h3, h4, h5, h6, p, li, table, blockquote`)),r=``;return n.forEach(t=>{let n=t.textContent?.trim()||``;if(!n)return;let i=t.tagName.toLowerCase();[`h1`,`h2`,`h3`,`h4`,`h5`,`h6`].includes(i)?(e.push(n),r+=`\n### ${n}\n\n`):r+=i===`blockquote`?`> ${n}\n\n`:i===`li`?`- ${n}\n`:`${n}\n\n`}),r.trim()||(r=t.innerText||``),{content:r.substring(0,25e3).trim(),headings:e.slice(0,15)}}function n(){let n=window.getSelection()?.toString().trim()||``,r=e(),{content:i,headings:a}=t();return{title:document.title||`Untitled Web Page`,url:window.location.href,domain:window.location.hostname,description:r.description,author:r.author,publishedDate:r.publishedDate,content:i,selectedText:n||void 0,hasSelection:n.length>0,headings:a}}function r(){if(document.getElementById(`docify-float-badge`)||window.location.protocol===`chrome-extension:`||window.location.protocol===`chrome:`)return;let e=document.createElement(`style`);e.textContent=`
    #docify-float-badge {
      position: fixed;
      bottom: 28px;
      right: 24px;
      z-index: 2147483647;
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 10px 16px 10px 12px;
      background: rgba(255, 255, 255, 0.72);
      backdrop-filter: blur(28px) saturate(200%);
      -webkit-backdrop-filter: blur(28px) saturate(200%);
      border: 1.5px solid rgba(255, 255, 255, 0.90);
      border-radius: 50px;
      box-shadow:
        0 0 0 0.5px rgba(167, 139, 250, 0.22),
        0 8px 32px rgba(100, 60, 220, 0.18),
        0 2px 8px rgba(0, 0, 0, 0.08),
        inset 0 1px 0 rgba(255, 255, 255, 1);
      cursor: pointer;
      transition: all 0.28s cubic-bezier(0.34, 1.56, 0.64, 1);
      user-select: none;
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
      animation: docifySlideIn 0.55s cubic-bezier(0.34, 1.56, 0.64, 1) forwards;
    }

    @keyframes docifySlideIn {
      0% { transform: translateY(80px) scale(0.8); opacity: 0; }
      100% { transform: translateY(0) scale(1); opacity: 1; }
    }

    #docify-float-badge:hover {
      transform: translateY(-3px) scale(1.04);
      box-shadow:
        0 0 0 0.5px rgba(167, 139, 250, 0.35),
        0 14px 44px rgba(100, 60, 220, 0.28),
        0 4px 14px rgba(0, 0, 0, 0.10),
        inset 0 1px 0 rgba(255, 255, 255, 1);
    }

    #docify-float-badge:active {
      transform: translateY(0) scale(0.97);
    }

    #docify-float-badge-icon {
      width: 28px;
      height: 28px;
      border-radius: 10px;
      background: linear-gradient(135deg, #7c3aed, #8b5cf6, #6366f1);
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
      box-shadow:
        0 3px 10px rgba(99, 60, 220, 0.30),
        inset 0 1px 0 rgba(255,255,255,0.25);
    }

    #docify-float-badge-icon svg {
      display: block;
    }

    #docify-float-badge-label {
      font-size: 12.5px;
      font-weight: 800;
      letter-spacing: 0.8px;
      background: linear-gradient(135deg, #7c3aed, #6366f1);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
      line-height: 1;
    }

    /* Ambient glow behind badge */
    #docify-float-badge::before {
      content: '';
      position: absolute;
      inset: -8px;
      border-radius: 60px;
      background: radial-gradient(circle at center,
        rgba(167, 139, 250, 0.18) 0%,
        transparent 70%);
      pointer-events: none;
      z-index: -1;
    }

    /* Pulse ring on the icon */
    #docify-pulse-ring {
      position: absolute;
      top: 50%;
      left: 12px;
      transform: translate(-50%, -50%);
      width: 28px;
      height: 28px;
      border-radius: 50%;
      border: 1.5px solid rgba(139, 92, 246, 0.40);
      animation: docifyPulse 2.5s ease-out infinite;
      pointer-events: none;
    }

    @keyframes docifyPulse {
      0% { transform: translate(-50%, -50%) scale(1); opacity: 0.7; }
      100% { transform: translate(-50%, -50%) scale(2.2); opacity: 0; }
    }

    /* Dismiss button */
    #docify-float-dismiss {
      position: absolute;
      top: -6px;
      right: -6px;
      width: 18px;
      height: 18px;
      border-radius: 50%;
      background: rgba(255,255,255,0.92);
      border: 1px solid rgba(167,139,250,0.25);
      display: none;
      align-items: center;
      justify-content: center;
      font-size: 10px;
      color: #9ca3af;
      cursor: pointer;
      box-shadow: 0 2px 6px rgba(0,0,0,0.10);
      line-height: 1;
    }

    #docify-float-badge:hover #docify-float-dismiss {
      display: flex;
    }
  `,document.head.appendChild(e);let t=document.createElement(`div`);t.id=`docify-float-badge`,t.setAttribute(`role`,`button`),t.setAttribute(`aria-label`,`Open Docify — convert this page to a document`),t.setAttribute(`title`,`Create a document from this page with Docify`);let n=document.createElement(`div`);n.id=`docify-pulse-ring`;let r=document.createElement(`div`);r.id=`docify-float-badge-icon`,r.innerHTML=`
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none"
         stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
      <polyline points="14 2 14 8 20 8"/>
      <line x1="16" y1="13" x2="8" y2="13"/>
      <line x1="16" y1="17" x2="8" y2="17"/>
    </svg>`;let i=document.createElement(`span`);i.id=`docify-float-badge-label`,i.textContent=`DOCIFY`;let a=document.createElement(`div`);a.id=`docify-float-dismiss`,a.innerHTML=`✕`,a.addEventListener(`click`,e=>{e.stopPropagation(),t.style.animation=`none`,t.style.transform=`translateY(80px) scale(0.8)`,t.style.opacity=`0`,t.style.transition=`all 0.3s ease`,setTimeout(()=>t.remove(),300)}),t.appendChild(n),t.appendChild(r),t.appendChild(i),t.appendChild(a),t.addEventListener(`click`,e=>{e.stopPropagation(),chrome.runtime.sendMessage({action:`OPEN_POPUP`})}),document.body.appendChild(t)}document.readyState===`loading`?document.addEventListener(`DOMContentLoaded`,r):r(),chrome.runtime.onMessage.addListener((e,t,r)=>{if(e.action===`EXTRACT_CONTENT`)r(n());else if(e.action===`GET_SELECTION`){let e=window.getSelection()?.toString().trim()||``;r({hasSelection:e.length>0,selectedText:e,title:document.title,url:window.location.href})}return!0});